package Test;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.*;

public class TS_Atlassian {

	WebDriver driver;
	Properties prop;
	
	@BeforeTest
	public void config() {

		prop = new Properties();
		try {
			InputStream input = new FileInputStream("src/main/resources/config.properties");
			prop.load(input);

			System. setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver_win.exe");
			driver  = new ChromeDriver();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void tc_restrictions() {
		
		try {
			Robot rob = new Robot();
			
			driver.get(prop.get("url").toString());
			driver.manage().window().maximize();
			Thread.sleep(4000);
			driver.findElement(By.xpath(PG_Login.tf_username.get())).sendKeys("hershini83@gmail.com");
			driver.findElement(By.xpath(PG_Login.btn_continue.get())).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath(PG_Login.tf_passward.get())).sendKeys("atlassian");
			driver.findElement(By.xpath(PG_Login.btn_login.get())).click();
			Thread.sleep(40000);
			driver.findElement(By.xpath(PG_Home.btn_restrictions.get())).click();
			Thread.sleep(4000);
			
			if(driver.findElements(By.xpath(PG_Home.lbl_everyoneCan.get())).size()>0) {
				System.out.println("\"Everyone can view and edit this page.\" is present");
			}else {
				System.out.println("\"Everyone can view and edit this page.\" is not present");
			}
			
			driver.findElement(By.xpath(PG_Home.lnk_help.get())).click();
			Thread.sleep(2000);
			driver.switchTo().window(new ArrayList<String> (driver.getWindowHandles()).get(1));
			Thread.sleep(4000);
			if(driver.findElements(By.xpath(PG_Help.lbl_header.get())).size()>0) {
				System.out.println("Successfully navigate to help page");
			}else {
				System.out.println("Navigate to help page faild");
			}
			driver.close();
			driver.switchTo().window(new ArrayList<String> (driver.getWindowHandles()).get(0));
			Thread.sleep(2000);
			
			driver.findElement(By.xpath(PG_Home.lnk_learnMoreAboutRestrictions.get())).click();
			Thread.sleep(2000);
			driver.switchTo().window(new ArrayList<String> (driver.getWindowHandles()).get(1));
			Thread.sleep(4000);
			if(driver.findElements(By.xpath(PG_Help.lbl_header.get())).size()>0) {
				System.out.println("Successfully navigate to learn More About Restrictions page");
			}else {
				System.out.println("Navigate to learn More About Restrictions page faild");
			}
			driver.close();
			driver.switchTo().window(new ArrayList<String> (driver.getWindowHandles()).get(0));
			Thread.sleep(2000);
			
			driver.findElement(By.xpath(PG_Home.lnk_inspectPermissions.get())).click();
			Thread.sleep(4000);
			if(driver.findElements(By.xpath(PG_Home.lbl_inspectPermissions.get())).size()>0) {
				System.out.println("Successfully navigate to inspect Permissions window");
			}else {
				System.out.println("Navigate to inspect Permissions window faild");
			}
			driver.findElement(By.xpath(PG_Home.btn_ok.get())).click();
			
			driver.findElement(By.xpath(PG_Home.ele_restrictionType.get())).click();
			Thread.sleep(4000);
			
			rob.keyPress(KeyEvent.VK_DOWN); 
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_ENTER); 
			Thread.sleep(4000);
			
			if(driver.findElements(By.xpath(PG_Home.ele_everyoneCanView.get())).size()>0) {
				System.out.println("\n\n\"Everyone can view\" is present");
			}else {
				System.out.println("\n\n\"Everyone can view\" is not present");
			}
			if(driver.findElements(By.xpath(PG_Home.ele_hershiniCanViewAndEdit.get())).size()>0) {
				System.out.println("\"Hershini Abeygunawardena can view and edit\" is present");
			}else {
				System.out.println("\"Hershini Abeygunawardena can view and edit\" is not present");
			}
			
			rob.keyPress(KeyEvent.VK_H);
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_E);
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_DOWN); 
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_ENTER); 
			Thread.sleep(4000);
			driver.findElement(By.xpath(PG_Home.btn_add.get())).click();
			Thread.sleep(2000);
			
			if(driver.findElements(By.xpath(PG_Home.ele_hershiniA.get())).size()>0) {
				System.out.println("\n\n\"Hershini.a\" is successfully added for editing restricted");
			}else {
				System.out.println("\n\n\"Hershini.a\" is not added for editing restricted");
			}
			driver.findElement(By.xpath(PG_Home.btn_remove.get())).click();
			

			driver.findElement(By.xpath(PG_Home.lnk_help.get())).click();
			Thread.sleep(2000);
			driver.switchTo().window(new ArrayList<String> (driver.getWindowHandles()).get(1));
			Thread.sleep(4000);
			if(driver.findElements(By.xpath(PG_Help.lbl_header.get())).size()>0) {
				System.out.println("Successfully navigate to help page");
			}else {
				System.out.println("Navigate to help page faild");
			}
			driver.close();
			driver.switchTo().window(new ArrayList<String> (driver.getWindowHandles()).get(0));
			

			driver.findElement(By.xpath(PG_Home.lnk_inspectPermissions.get())).click();
			Thread.sleep(2000);
			if(driver.findElements(By.xpath(PG_Home.lbl_inspectPermissions.get())).size()>0) {
				System.out.println("Successfully navigate to inspect Permissions window");
			}else {
				System.out.println("Navigate to inspect Permissions window faild");
			}
			driver.findElement(By.xpath(PG_Home.btn_ok.get())).click();
			
			driver.findElement(By.xpath(PG_Home.ele_restrictionType.get())).click();
			Thread.sleep(4000);
			
			rob.keyPress(KeyEvent.VK_DOWN); 
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_DOWN); 
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_ENTER); 
			Thread.sleep(4000);
			
			if(driver.findElements(By.xpath(PG_Home.ele_everyoneHasNoAccess.get())).size()>0) {
				System.out.println("\n\n\"Everyone Has no access\" is present");
			}else {
				System.out.println("\n\n\"Everyone Has no access\" is not present");
			}
			if(driver.findElements(By.xpath(PG_Home.ele_hershiniCanViewAndEdit2.get())).size()>0) {
				System.out.println("\"Hershini Abeygunawardena can view and edit\" is present");
			}else {
				System.out.println("\"Hershini Abeygunawardena can view and edit\" is not present");
			}
			
			driver.findElement(By.xpath(PG_Home.tf_user.get())).click();
			rob.keyPress(KeyEvent.VK_H);
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_E);
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_DOWN); 
			Thread.sleep(2000);
			rob.keyPress(KeyEvent.VK_ENTER); 
			Thread.sleep(4000);
			driver.findElement(By.xpath(PG_Home.btn_add.get())).click();
			Thread.sleep(2000);
			
			if(driver.findElements(By.xpath(PG_Home.ele_hershiniA.get())).size()>0) {
				System.out.println("\n\n\"Hershini.a\" is successfully added for viewing and editing restricted");
			}else {
				System.out.println("\n\n\"Hershini.a\" is not added for viewing and editing restricted");
			}
			driver.findElement(By.xpath(PG_Home.btn_remove.get())).click();
			
			
			driver.findElement(By.xpath(PG_Home.btn_cancel.get())).click();
			Thread.sleep(4000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void close() {
		driver.close();
	}
}
