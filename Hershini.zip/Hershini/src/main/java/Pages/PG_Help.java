package Pages;

public enum PG_Help {

	lbl_header("//h1[text()='Add or Remove Page Restrictions']");
	
	String locator;
	
	PG_Help(String locator){
		this.locator = locator;
	}
	
	public String get() {
		return locator;
	}
}
