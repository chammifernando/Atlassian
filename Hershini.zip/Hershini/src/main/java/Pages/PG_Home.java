package Pages;

public enum PG_Home {

	btn_restrictions("//button[@data-test-id='restrictions.dialog.button']"),
	ele_restrictionType("//div[@data-test-id='restrictions-dialog.content-mode-select']"),
	lbl_everyoneCan("//span[text()='Everyone can view and edit this page.']"),
	ele_everyoneCanView("//span[text()='Everyone']//preceding::thead//following::td/span[text()='Can view']"),
	ele_hershiniCanViewAndEdit("//div[text()='Hershini Abeygunawardena']//preceding::thead//following::td/span[text()='Can view and edit']"),
	ele_hershiniCanViewAndEdit2("(//div[text()='Hershini Abeygunawardena']//preceding::thead//following::td)[5]//span[text()='Can view and edit']"),
	ele_everyoneHasNoAccess("(//span[text()='Everyone']//preceding::thead//following::td)[2]//span[text()='Has no access']"),
	ele_hershiniA("//div[text()='hershini.a']"),
	btn_cancel("//span[text()='Cancel']"),
	btn_apply("//span[text()='Apply']"),
	btn_add("//span[text()='Add']"),
	btn_ok("//span[text()='OK']"),
	btn_remove("//span[text()='Remove']"),
	tf_user("//span[text()='Type a user name or group']/.."),
	lnk_help("//span[text()='Help']"),
	lnk_learnMoreAboutRestrictions("//span[text()='Learn more about restrictions.']"),
	lnk_inspectPermissions("//span[text()='Inspect permissions']"),
	lbl_inspectPermissions("//span[text()='Inspect permissions']");

	String locator;
	
	PG_Home(String locator){
		this.locator = locator;
	}
	
	public String get() {
		return locator;
	}
}
