package Pages;


public enum PG_Login {

	tf_username("//input[@id='username']"),
	btn_continue("//span[text()='Continue']/.."),
	tf_passward("//input[@id='password']"),
	btn_login("//span[text()='Log in']/..");
	
	String locator;
	
	PG_Login(String locator){
		this.locator = locator;
	}
	
	public String get() {
		return locator;
	}
}
